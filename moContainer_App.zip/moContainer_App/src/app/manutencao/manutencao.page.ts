import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manutencao',
  templateUrl: './manutencao.page.html',
  styleUrls: ['./manutencao.page.scss'],
})
export class ManutencaoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
