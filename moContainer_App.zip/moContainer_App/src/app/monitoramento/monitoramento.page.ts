//import { Component, OnInit } from '@angular/core';
import { Component} from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import * as mqtt from '../../js/mqtt.min';


@Component({
  selector: 'app-monitoramento',
  templateUrl: './monitoramento.page.html',
  styleUrls: ['./monitoramento.page.scss'],
})
export class MonitoramentoPage {

  messageList: any[] = [];
  client;

  constructor(
    private router: Router,
    public httpClient: HttpClient) {
  }
  

  ngOnInit() {
    this.mqttConnect();
  }


mqttConnect() {
  try {
    
    let that = this; //Referencia para chamar variáveis do angular dentro da       

    //COnfiguração do Broker. (Websockets)
    var options = {
      clientId: 'testCeiot_1',
      connectTimeout: 10000,
      hostname: 'test.mosquitto.org',
      port: 8080,
      path: '/mqtt'
    };
    
    //Conexão
    this.client = mqtt.connect(options);
    
    //Se inscreve em um tópico ao se conectar ao broker
    this.client.on('connect', function () {
      that.client.subscribe('ceiot', function (err) {
        if (!err) {
          that.client.publish('ceiot', 'Hello mqtt')
        }
      })
    });

    //Tratamento ao receber mensagem
    this.client.on('message', function (topic, message) {
          that.receiveMessage(topic, message);
    });

  } catch (e) {
    console.log(e);
  }
}

/**
 * Adiciona tópico e mensagem no array messageList
 * @param topic 
 * @param message 
 */
receiveMessage(topic, message)
{ 
  console.log(message.toString())      
  var obj = {};
  obj['topic'] = topic;
  obj['message'] = message;
  this.messageList.push(obj);
}

public publish(msg)
{
  this.client.publish('ceiot', msg);
}

public publish2()
{
  this.client.publish('ceiot', "TESTE");
}

public sub(topic)
{
  this.client.subscribe(topic, function (err) {
    if (!err) {
      console.log("Sucesso ao fazer subscribe");
    }
  })
}
}