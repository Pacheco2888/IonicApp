# Ionic 4 and Angular 6 Tutorial: Firebase Realtime CRUD Mobile App

This source code is part of [Ionic 4 and Angular 6 Tutorial: Firebase Realtime CRUD Mobile App](https://www.djamware.com/post/5b74e54f80aca74669894413/ionic-4-and-angular-6-tutorial-firebase-realtime-crud-mobile-app) tutorial.

To run locally:

* Clone this repo
* Run `npm install`
* Run `ionic serve -l`
