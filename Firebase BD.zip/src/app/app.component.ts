import { Component } from '@angular/core';

import { Platform } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import * as firebase from 'firebase';

const config = {
  
  apiKey: "AIzaSyCKCULrus0pJybMrleZB_l5QmOOH-wlo8E",
  authDomain: "monitoramento-container.firebaseapp.com",
  databaseURL: "https://monitoramento-container.firebaseio.com",
  projectId: "monitoramento-container",
  storageBucket: "monitoramento-container.appspot.com",
  messagingSenderId: "1006552315491",
  appId: "1:1006552315491:web:12057fbfbf5edb44"
  
  /*
  apiKey: 'AIzaSyC2lj_yaQ1-OqYzxpJhjdbVRSS15p20jQM',
  authDomain: 'bulletinboard-d4583.firebaseapp.com',
  databaseURL: 'https://bulletinboard-d4583.firebaseio.com/',
  projectId: 'bulletinboard-d4583',
  storageBucket: 'gs://bulletinboard-d4583.appspot.com',
*/
};

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html'
})
export class AppComponent {
  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
    firebase.initializeApp(config);
  }
}
